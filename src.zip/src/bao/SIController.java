package bao;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import dao.SI;

@Controller
public class SIController {
@RequestMapping("siload")
public ModelAndView siLoad()
{
	return new ModelAndView("siview","command",new SI());
}
@RequestMapping("sicode")
public ModelAndView siCode(@ModelAttribute("spring-web-mvc")SI s)
{
	float si = (s.getP() * s.getR()* s.getT())/100;
	//ModelAndView obj = new ModelAndView("siview","command",new SI());
	//obj.addObject("key","result is "+si);
	//return obj;
	return new ModelAndView("siview","command",new SI()).addObject("key","result is "+si);
	//return new ModelAndView("sires","key","result is "+si);
}
}
