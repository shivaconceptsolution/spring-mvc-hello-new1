package dao;

public class SI {
private float p;
private float r;
private float t;
public float getP() {
	return p;
}
public void setP(float p) {
	this.p = p;
}
public float getR() {
	return r;
}
public void setR(float r) {
	this.r = r;
}
public float getT() {
	return t;
}
public void setT(float t) {
	this.t = t;
}

}
